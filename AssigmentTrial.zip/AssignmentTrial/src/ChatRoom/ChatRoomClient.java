package ChatRoom;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

public class ChatRoomClient {

    private static JFrame frame;
    private static JTextField usernameField;
    private static JButton connectButton;
    private static JButton disconnectButton; // Added disconnect button
    private static JTextArea chatArea;
    private static JTextField messageField;
    private static JButton sendButton;

    private static Socket socket;
    private static PrintWriter writer;
    private static Scanner serverInput;

    public static void main(String[] args) {
        createGUI();

        connectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String username = usernameField.getText();
                if (!username.isEmpty()) {
                    connectToServer(username);
                    sendWelcomeMessage(username);
                    connectButton.setEnabled(false);
                    disconnectButton.setEnabled(true);
                } else {
                    JOptionPane.showMessageDialog(frame, "Please enter a username.");
                }
            }
        });

        disconnectButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                disconnectFromServer();
            }
        });

        sendButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                sendMessage();
            }
        });
    }

    private static void createGUI() {
        frame = new JFrame("Chat Room Client");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(800, 500);
        frame.setLayout(new BorderLayout());

        usernameField = new JTextField();
        connectButton = new JButton("Connect");
        disconnectButton = new JButton("Disconnect"); // Added disconnect button
        chatArea = new JTextArea();
        messageField = new JTextField();
        sendButton = new JButton("Send");

        JPanel topPanel = new JPanel();
        topPanel.setLayout(new FlowLayout());
        topPanel.add(new JLabel("Username:"));
        usernameField.setPreferredSize(new Dimension(150, usernameField.getPreferredSize().height));
        topPanel.add(usernameField);
        topPanel.add(connectButton);
        topPanel.add(disconnectButton); // Added disconnect button

        frame.add(topPanel, BorderLayout.NORTH);
        frame.add(new JScrollPane(chatArea), BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new BorderLayout());
        bottomPanel.add(messageField, BorderLayout.CENTER);
        bottomPanel.add(sendButton, BorderLayout.EAST);

        frame.add(bottomPanel, BorderLayout.SOUTH);

        disconnectButton.setEnabled(false); // Disable disconnect button initially
        frame.setVisible(true);
    }

    private static void connectToServer(String username) {
        try {
            socket = new Socket("localhost", 12342);
            writer = new PrintWriter(socket.getOutputStream(), true);
            serverInput = new Scanner(socket.getInputStream());

            // Start a separate thread to listen for server messages
            Thread serverListener = new Thread(() -> {
                while (serverInput.hasNextLine()) {
                    String serverMessage = serverInput.nextLine();
                    chatArea.append(serverMessage + "\n");

                    // Check if the server message indicates a client disconnection
                    if (serverMessage.contains(" is disconnected")) {
                        // Display a message for client disconnection
                        chatArea.append(serverMessage + "\n");
                    }
                }
            });
            serverListener.start();

            // Send the username to the server
            writer.println(username);

            // Disable the username field and connect button after connecting
            usernameField.setEnabled(false);
            connectButton.setEnabled(false);

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to connect to the server.");
        }
    }

    private static void disconnectFromServer() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
                usernameField.setEnabled(true);
                connectButton.setEnabled(true);
                disconnectButton.setEnabled(false);
                chatArea.append("You are disconnected\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(frame, "Failed to disconnect from the server.");
        }
    }

    private static void sendWelcomeMessage(String username) {
        // Send the "You are connected" message to the server
        writer.println("You are connected");
        // Display a personalized welcome message for the client
       // chatArea.append(username + " is connected \n");
    }

    private static void sendMessage() {
        String message = messageField.getText();
        if (!message.isEmpty()) {
            writer.println(message);
            messageField.setText("");
        }
    }
}