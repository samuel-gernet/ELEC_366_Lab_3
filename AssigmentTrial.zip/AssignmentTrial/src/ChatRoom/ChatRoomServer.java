package ChatRoom;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class ChatRoomServer {

    private static List<ClientHandler> clients = new ArrayList<>();
    private static Set<String> usedNames = new HashSet<>();

    public static void main(String[] args) {
        try (ServerSocket serverSocket = new ServerSocket(12342)) {
            System.out.println("Server is running...");

            while (true) {
                Socket clientSocket = serverSocket.accept();
                System.out.println("New client connected");

                PrintWriter writer = new PrintWriter(clientSocket.getOutputStream(), true);
                Scanner reader = new Scanner(clientSocket.getInputStream());

                // Read the client's name
                String clientName = reader.nextLine();

                if (!isNameAvailable(clientName)) {
                    // Refuse connection and notify the client
                    writer.println("Name in use. Please choose a different name.");
                    clientSocket.close();
                    continue;
                }

                // Mark the name as used
                usedNames.add(clientName);

                // Create a new ClientHandler for the client
                ClientHandler clientHandler = new ClientHandler(clientSocket, writer, clientName);
                clients.add(clientHandler);

                // Start a separate thread to handle the client
                Thread clientThread = new Thread(clientHandler);
                clientThread.start();

                // Broadcast the connection to all clients
                broadcast(clientName + " is connected");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static boolean isNameAvailable(String name) {
        return !usedNames.contains(name);
    }

    private static void broadcast(String message) {
        for (ClientHandler client : clients) {
            client.sendMessage(message);
        }
    }

    private static class ClientHandler implements Runnable {
        private Socket clientSocket;
        private PrintWriter writer;
        private String name;

        public ClientHandler(Socket clientSocket, PrintWriter writer, String name) {
            this.clientSocket = clientSocket;
            this.writer = writer;
            this.name = name;
        }

        @Override
        public void run() {
            try {
                Scanner reader = new Scanner(clientSocket.getInputStream());

                while (reader.hasNextLine()) {
                    String message = reader.nextLine();
                    broadcast(name + ": " + message);
                }
            } catch (IOException e) {
                // Handle client disconnection
                System.out.println(name + " disconnected");
                usedNames.remove(name);
                clients.remove(this);
                broadcast(name + " is disconnected");
            }
        }

        public void sendMessage(String message) {
            writer.println(message);
        }
    }
}