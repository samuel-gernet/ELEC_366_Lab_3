package ChatRoom;

import java.io.IOException;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.HashSet;
import java.util.Scanner;
import java.util.Set;

public class ClientHandler implements Runnable {

    private Socket clientSocket;
    private PrintWriter writer;
    private String name;
    private static Set<String> usedNames = new HashSet<>();
    private static Set<ClientHandler> clients = new HashSet<>();

    public ClientHandler(Socket clientSocket) {
        this.clientSocket = clientSocket;
    }

    @Override
    public void run() {
        try {
            Scanner reader = new Scanner(clientSocket.getInputStream());
            writer = new PrintWriter(clientSocket.getOutputStream(), true);

            // Read the client's name
            name = reader.nextLine();

            synchronized (usedNames) {
                if (usedNames.contains(name)) {
                    // Refuse connection and notify the client
                    writer.println("Name in use. Please choose a different name.");
                    clientSocket.close();
                    return;
                }

                // Mark the name as used
                usedNames.add(name);
            }

            // Add this client to the set of clients
            synchronized (clients) {
                clients.add(this);
            }

            sendMessage("You are connected");
            
            // Broadcast the connection to all clients
            broadcast(name + " is connected");

            while (reader.hasNextLine()) {
                String message = reader.nextLine();
                broadcast(name + ": " + message);
            }
        } catch (IOException e) {
            // Handle client disconnection
            System.out.println(name + " disconnected");
            usedNames.remove(name);
            synchronized (clients) {
                clients.remove(this);
            }
            broadcast(name + " is disconnected");
        }
    }

    private static boolean isNameAvailable(String name) {
        synchronized (usedNames) {
            return !usedNames.contains(name);
        }
    }

    private static void broadcast(String message) {
        synchronized (clients) {
            for (ClientHandler client : clients) {
                if (client != null) {
                    if (client.equals(client)) {
                        // Send only the connection message to the current client
                        client.sendMessage(message);
                    } else {
                        // Send the regular chat message to other clients
                        client.sendMessage("Client " + message);
                    }
                }
            }
        }
    }

    public void sendMessage(String message) {
        writer.println(message);
    }
}
