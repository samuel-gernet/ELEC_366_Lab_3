/**
 * 
 */
/**
 * 
 */
module AssignmentTrial {
	requires java.desktop;
}